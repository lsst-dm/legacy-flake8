example = lambda: 'example'  # noqa: E731
